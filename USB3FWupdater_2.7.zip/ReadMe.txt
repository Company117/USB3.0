PassMark USB3Test V2.7
Copyright (C) 2012-2024 PassMark Software
All Rights Reserved
http://www.passmark.com

Overview
========
PassMark USB3 Firmware Updater is a simple Windows 
based application that allows users to update the 
firmware on their USB 3.0 loopback plug to the latest
release version.USB3 Firmware Updater is designed for 
use in conjunction with PassMark's USB 3.0 loopback 
plug and will successfully update the device's firmware 
connected through a USB 2.0 or USB 3.0 port.

Warning
=======
Only program your device using official PassMark firmware
released for the USB 3.0 loopback plug. Programming using
an incompatible ".img" file may permanently break your plug.

Installation
============
1) Unzip the files from the downloaded ".zip" file
2) Ensure that the ".img" files including 
   "CyBootProgrammer.img", "mfw.img", and "usb30test.img"
   are in the same directory as the ".exe" 
3) Double click (or Open) the ".exe" file

UnInstallation
==============
Just delete the installation directory.

Requirements
============
CPU:
80486 200Mhz or faster.

Operating System: 
Windows 7, 8, 10 and 11.

64Meg RAM
1 Meg of free hard disk space to install the software
USB 3 or 2 ports

Firmware Version History
========================
Here's a summary of all the changes that have been made in 
each version of the firmware for the USB 3.0 Loopback Plug.

V2.7 19/January/2024
- Fixed an issue where the plug was experiencing enumeration failure at USB2 Full speed. Compiled firmware using SDK 1.3.3

V2.6 10/November/2021
- Changed the LCD initialization routine to improve contrast

V2.5 4/October/2017
- Modified the firmware in order to detect port speed when driver is not installed

V2.4 13/June/2017
- Added a firmware validation feature to check firmware corruption

V2.3 14/November/2016
- Implemented CONFIG_LPM_ENTRY command to allow enabling and disabling of U1/U2 sleep modes entry. Disabling U1/U2 sleep entry during the test eliminates the surge current needed for re enabling of the USB3 PHY transceiver. This surge current lead to sudden drop in the plug's supply voltage and 8b/10b decoding errors
- Added plug's serial number to the first screen message

V2.2 25/October/2016
- Implemented CLEAR FEATURE request to allow the host to reset the endpoint after it has entered the STALL condition
- Moved all Vendor Request's processing to the main thread
- These changes allow better recovery from low level signal integrity errors. Previously corrupted data, for example due to a bad cable, could result in a hang condition in the firmware. Applications can now log the error, reset the transfer and continue testing

v2.1 31/August/2016
- Fixed a re-enumeration issue with Cypress CY4609, Texas Instruments TUSB8041 and Microchip USB5534B hubs

v2.0 17/June/2016
- Benchmark result enhanced by increasing the buffer size and optimizing the firmware (buffers optimized based on test mode, firmware code optimized, data and stack size optimized, compiler speed and size optimization enabled) 
- Loopback buffer size is increased to 64K bytes
- SET_CONFIG command changed to allow the Test application to change buffer size and buffer count based on test mode and endoint type
- Added firmware feature to select the enumeration speed i.e. switching between Super-Speed(5Gb/s), High-Speed(480Mb/s) and Full-Speed(12Mb/s) is possible via Test application
- Added Low-level error reporting feature
  CONF_ERROR_COUNTERS command allows configuration of the USB3.0 PHY/Link layer error counters
  GET_ERROR_COUNTS Indicates the occurrence of each PHY/Link layer error type since it was last read
- Fixed isochronous issue with high-bandwidth transfers (number of transfers per microframe > 1) in high speed mode
- Isochronous descriptors changed to have one endpoint at a time in benchmark test to avoid getting "Not enough USB controller resources" error from the host controller driver
- Fixed issue of displaying LCD messages in application when device is enumeratedas Full-Speed
- Added GET_DEVICE_INFO command to get the plug's firmware version 
- Added GET_MAX_SPEED command to get the maximum speed supported by the USB port

v1.7 7/March/2016
- Resolved volts too high issue occuring during loopback test
- Resolved blank LCD issue occurs after long period of test

v1.6 23/December/2015
- Compiled image using latest SDK 1.3.3.

v1.5 26/September/2014
- Changed LCD update frequency to minimise "failed to read voltage 
  data, device might be busy". 
- Fixed LCD spacing bug.
- Compiled image using latest SDK 1.2.4.

v1.4 11/March/2013
- Disabled suspend entry during sleep for continued voltage
  measurement

v1.3 22/February/2013
- Disabled suspend entry for USB 2.0 
- Removed 'check plug connection' message during suspend

v1.2 13/February/2013
- Changed voltage error message from "voltage too high/low" 
  to "volts too high/low"

v1.1 6/February/2013
- Fixed a bug with ADC readout 
- Mirrored LCD spacing fixed 

Troubleshooting
===============
If you are having difficulty programming the device, open 
an instance of 
"Device Manager" and "PassMark USB3.0 Loopback Firmware Updater" 

- Before deleting the existing firmware on the device, check
  the plug comes up in:
  Device Manager >> USB controllers >> PassMark USB3.0 Loopback plug

- After clicking "DELETE", check the plug comes up in:
  Device Manager >> USB controllers >> Cypress USB Bootloader
  If it does not, unplug and replug the device.

- After clicking "PROGRAM", check the plug comes up in:
  Device Manager >> USB Controllers >> Cypress USB BootProgrammer

- After removing and reconnecting the device, check the plug comes up in:
  Device Manager >> USB Controllers >> PassMark USB3.0 Loopback plug

Each step may take some time for the device driver software to be 
installed and recognised by Device Manager. 


Support
=======
For technical support, questions, suggestions, Mail us at
help@passmark.com
or visit our web page at
http://www.passmark.com


Ordering / Registration
=======================
All the details are in the online documentation
or you can visit our sales information page
http://www.passmark.com/sales

Enjoy..
The PassMark Development team
